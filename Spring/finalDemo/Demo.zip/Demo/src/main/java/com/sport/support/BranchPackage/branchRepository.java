package com.sport.support.BranchPackage;

import org.springframework.data.repository.CrudRepository;

public interface branchRepository extends CrudRepository<branch, Long> {

	branch findDistinctById(int id);
}
